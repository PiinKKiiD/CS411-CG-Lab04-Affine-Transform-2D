#pragma once
#include "glut.h"

void setLibColor()
{
	glColor3f(1, 1, 1);
}

void setMyColor()
{
	glColor3f(1.0f, 0.75f, 0.0f);
}

