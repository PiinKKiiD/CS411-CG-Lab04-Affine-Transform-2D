#include "Shape.h"
#ifndef TOMAU_H_
#define TOMAU_H_
class ToMau {

};

// XAnh
//Do
//Vang

#endif 
